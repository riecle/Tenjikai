# 差分適用手順

このZIPはシステム本体を含みません。manifest.jsonのoperationsに従い、delta配下をキー重複なしで追記してください。

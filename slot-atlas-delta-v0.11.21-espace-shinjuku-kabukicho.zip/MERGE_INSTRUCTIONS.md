# 適用手順
各 delta/*.json を manifest.json の operation に従って追記してください。キー重複時は停止し、上書きしないでください。システム本体は含みません。

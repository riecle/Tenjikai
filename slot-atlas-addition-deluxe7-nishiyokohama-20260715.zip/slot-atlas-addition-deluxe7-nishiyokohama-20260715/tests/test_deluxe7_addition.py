import csv
import datetime as dt
import json
import pathlib
import sys
import unittest

ROOT = pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
import slot_atlas


class Deluxe7NishiyokohamaAdditionTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.halls = json.loads((ROOT / "seed" / "halls.json").read_text(encoding="utf-8"))
        cls.rules = json.loads((ROOT / "seed" / "rules.json").read_text(encoding="utf-8"))
        cls.holidays = json.loads((ROOT / "seed" / "holidays.json").read_text(encoding="utf-8"))
        cls.hall = next(h for h in cls.halls if h["hall_id"] == "yokohama_deluxe7_nishiyokohama")

    def test_regular_day7_is_a_candidate(self):
        row = slot_atlas.forecast_one(self.hall, self.rules, dt.date(2026, 9, 7), dt.date(2026, 7, 15), self.holidays)
        self.assertEqual(row["rule_id"], "d7ny_regular_day7_strong")
        self.assertAlmostEqual(row["predicted_mean"], 124.3, places=1)
        self.assertAlmostEqual(row["utility_edge"], 89.3, places=1)
        self.assertEqual(row["rank"], "A")

    def test_anniversary_overrides_regular_day7(self):
        row = slot_atlas.forecast_one(self.hall, self.rules, dt.date(2026, 8, 7), dt.date(2026, 7, 15), self.holidays)
        self.assertEqual(row["rule_id"], "d7ny_anniversary_0807_avoid")
        self.assertEqual(row["rank"], "NO BET")

    def test_17_and_27_are_no_bet(self):
        for target, rule_id in ((dt.date(2026, 7, 17), "d7ny_day17_avoid"), (dt.date(2026, 7, 27), "d7ny_day27_avoid")):
            row = slot_atlas.forecast_one(self.hall, self.rules, target, dt.date(2026, 7, 15), self.holidays)
            self.assertEqual(row["rule_id"], rule_id)
            self.assertEqual(row["rank"], "NO BET")

    def test_seed_has_32_unique_dates_and_regular_day7_metrics(self):
        with (ROOT / "seed" / "deluxe7_nishiyokohama_hall_days.csv").open(encoding="utf-8-sig", newline="") as fh:
            rows = list(csv.DictReader(fh))
        self.assertEqual(len(rows), 32)
        self.assertEqual(len({r["result_date"] for r in rows}), 32)
        day7 = [r for r in rows if r["result_date"][8:] == "07" and r["result_date"] != "2024-08-07" and r["result_date"] != "2025-08-07"]
        self.assertEqual(len(day7), 18)
        values = [float(r["avg_diff"]) for r in day7]
        self.assertAlmostEqual(sum(values) / len(values), 151.9444, places=3)
        self.assertEqual(sum(v > 0 for v in values), 15)

    def test_validation_queue_has_four_tasks(self):
        queue = json.loads((ROOT / "seed" / "validation_queue.json").read_text(encoding="utf-8"))
        self.assertEqual(len([r for r in queue if r["hall_id"] == "yokohama_deluxe7_nishiyokohama"]), 4)


if __name__ == "__main__":
    unittest.main()

#!/usr/bin/env python3
"""Apply the DELUXE 7 Nishiyokohama addition to Slot Atlas 0.11.12."""
from __future__ import annotations
import argparse, hashlib, json, re, shutil, sys, tempfile
from pathlib import Path

BASE_MODEL = "slot-atlas-0.11.12"
HALL_ID = "yokohama_deluxe7_nishiyokohama"
ADD_DIR = Path(__file__).resolve().parent


def load_json(path: Path):
    with path.open(encoding="utf-8") as fh:
        return json.load(fh)


def atomic_json(path: Path, data) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.NamedTemporaryFile("w", encoding="utf-8", dir=path.parent, delete=False) as fh:
        json.dump(data, fh, ensure_ascii=False, indent=2); fh.write("\n"); tmp = Path(fh.name)
    tmp.replace(path)


def merge_unique(target: Path, additions: Path, key_fn) -> tuple[int, int]:
    current, extra = load_json(target), load_json(additions)
    if not isinstance(current, list) or not isinstance(extra, list):
        raise ValueError(f"list expected: {target} / {additions}")
    by_key = {key_fn(item): item for item in current}; added = identical = 0
    for item in extra:
        key = key_fn(item)
        if key in by_key:
            if by_key[key] != item: raise ValueError(f"conflicting existing record in {target.name}: {key}")
            identical += 1; continue
        current.append(item); by_key[key] = item; added += 1
    atomic_json(target, current); return added, identical


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as fh:
        for chunk in iter(lambda: fh.read(1024 * 1024), b""): h.update(chunk)
    return h.hexdigest()


def patch_integrity_test(test_path: Path) -> str:
    text = test_path.read_text(encoding="utf-8")
    if f'self.assertIn("{HALL_ID}", self.by_id)' in text:
        return "already_patched"
    pattern = re.compile(
        r"def test_merged_hall_set_has_(\d+)_unique_halls\(self\):\n"
        r"\s+self\.assertEqual\(len\(self\.halls\), (\d+)\)\n"
        r"\s+self\.assertEqual\(len\(self\.by_id\), (\d+)\)"
    )
    m = pattern.search(text)
    if not m or len(set(m.groups())) != 1:
        raise ValueError("unexpected hall-count block; review patches/test_merge_integrity_44_to_45.diff")
    old_n = int(m.group(1)); new_n = old_n + 1
    replacement = (
        f"def test_merged_hall_set_has_{new_n}_unique_halls(self):\n"
        f"        self.assertEqual(len(self.halls), {new_n})\n"
        f"        self.assertEqual(len(self.by_id), {new_n})"
    )
    text = text[:m.start()] + replacement + text[m.end():]
    anchor = '        self.assertIn("ueno_espace_shinkan", self.by_id)\n'
    tsuzuki = '        self.assertIn("tsuzuki_maruhan", self.by_id)\n'
    insert_after = tsuzuki if tsuzuki in text else anchor
    if insert_after not in text: raise ValueError("test patch anchor not found")
    text = text.replace(insert_after, insert_after + f'        self.assertIn("{HALL_ID}", self.by_id)\n', 1)
    test_path.write_text(text, encoding="utf-8")
    return f"patched_{old_n}_to_{new_n}"


def main() -> int:
    p=argparse.ArgumentParser(); p.add_argument("target",type=Path,help="unpacked Slot Atlas root"); p.add_argument("--force-version",action="store_true"); args=p.parse_args()
    root=args.target.resolve(); seed=root/"seed"
    required=[root/"slot_atlas.py",seed/"halls.json",seed/"rules.json",seed/"validation_queue.json",seed/"source_snapshots.json"]
    missing=[str(x) for x in required if not x.exists()]
    if missing: print("missing target files:\n- "+"\n- ".join(missing),file=sys.stderr); return 2
    if BASE_MODEL not in (root/"slot_atlas.py").read_text(encoding="utf-8") and not args.force_version:
        print(f"target is not {BASE_MODEL}; use --force-version only after schema review",file=sys.stderr); return 3
    original_count=len(load_json(seed/"halls.json"))
    backup=seed/"_addition_backups"/"20260715_deluxe7_nishiyokohama"; backup.mkdir(parents=True,exist_ok=True)
    for name in ["halls.json","rules.json","validation_queue.json","source_snapshots.json"]:
        if not (backup/name).exists(): shutil.copy2(seed/name,backup/name)
    test_path=root/"tests"/"test_merge_integrity.py"
    if test_path.exists() and not (backup/"test_merge_integrity.py.bak").exists(): shutil.copy2(test_path,backup/"test_merge_integrity.py.bak")
    results={}
    results["halls"]=merge_unique(seed/"halls.json",ADD_DIR/"seed"/"halls_additions.json",lambda x:x["hall_id"])
    results["rules"]=merge_unique(seed/"rules.json",ADD_DIR/"seed"/"rules_additions.json",lambda x:x["rule_id"])
    results["validations"]=merge_unique(seed/"validation_queue.json",ADD_DIR/"seed"/"validation_queue_additions.json",lambda x:(x["target_date"],x["hall_id"],x["claim"]))
    results["snapshots"]=merge_unique(seed/"source_snapshots.json",ADD_DIR/"seed"/"source_snapshots_additions.json",lambda x:(x["hall_id"],x["source_name"],x["fetched_at"]))
    test_status=patch_integrity_test(test_path) if test_path.exists() else "not_present"
    src=ADD_DIR/"seed"/"deluxe7_nishiyokohama_hall_days.csv"; dst=seed/src.name
    if dst.exists():
        if sha256(src)!=sha256(dst): raise ValueError(f"conflicting CSV already exists: {dst}")
        csv_status="identical"
    else: shutil.copy2(src,dst); csv_status="copied"
    src_test=ADD_DIR/"tests"/"test_deluxe7_addition.py"; dst_test=root/"tests"/src_test.name
    if dst_test.exists():
        if sha256(src_test)!=sha256(dst_test): raise ValueError(f"conflicting test already exists: {dst_test}")
        add_test_status="identical"
    else: shutil.copy2(src_test,dst_test); add_test_status="copied"
    final_count=len(load_json(seed/"halls.json"))
    expected=original_count + (1 if results["halls"][0] else 0)
    if final_count != expected: raise ValueError(f"hall count mismatch: expected {expected}, got {final_count}")
    print("DELUXE 7 Nishiyokohama addition applied")
    for label,(added,identical) in results.items(): print(f"- {label}: added={added}, already_identical={identical}")
    print(f"- hall-days CSV: {csv_status}")
    print(f"- addition tests: {add_test_status}")
    print(f"- compatibility test patch: {test_status}")
    print(f"- halls: {original_count} -> {final_count}")
    print(f"- backups: {backup}")
    print("Next: python3 slot_atlas.py init && python3 slot_atlas.py generate --start 2026-07-15 --run-date 2026-07-15")
    return 0

if __name__ == "__main__": raise SystemExit(main())

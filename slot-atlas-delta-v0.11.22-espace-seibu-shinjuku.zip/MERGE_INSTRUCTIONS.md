# 適用手順
manifest.json の operations 順に append_by_key / append / add_file を適用してください。システム本体は含みません。

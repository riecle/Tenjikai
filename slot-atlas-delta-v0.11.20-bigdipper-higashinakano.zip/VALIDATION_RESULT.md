# VALIDATION RESULT

- JSON parse: PASS (5 files)
- hall_id consistency: PASS
- Unique rule_id: PASS (8/8)
- Unique route_id: PASS
- Manifest sources: PASS
- CSV parse: PASS
- Full-system integration: NOT RUN（差分ZIPのみ）
- Expected after merge: 52 halls / 18,980 candidate rows

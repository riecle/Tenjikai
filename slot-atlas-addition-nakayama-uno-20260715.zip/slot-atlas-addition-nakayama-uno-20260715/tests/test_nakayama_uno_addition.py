import csv
import datetime as dt
import json
import pathlib
import sys
import unittest

ROOT = pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
import slot_atlas


class NakayamaUnoAdditionTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.halls = json.loads((ROOT / "seed" / "halls.json").read_text(encoding="utf-8"))
        cls.rules = json.loads((ROOT / "seed" / "rules.json").read_text(encoding="utf-8"))
        cls.holidays = json.loads((ROOT / "seed" / "holidays.json").read_text(encoding="utf-8"))
        cls.hall = next(h for h in cls.halls if h["hall_id"] == "yokohama_nakayama_uno")

    def test_month_start_is_b_candidate(self):
        row = slot_atlas.forecast_one(self.hall, self.rules, dt.date(2026, 8, 1), dt.date(2026, 7, 15), self.holidays)
        self.assertEqual(row["rule_id"], "nku_month_start_day1_monitor")
        self.assertAlmostEqual(row["predicted_mean"], 43.1, places=1)
        self.assertAlmostEqual(row["utility_edge"], 13.1, places=1)
        self.assertEqual(row["rank"], "B")

    def test_regular_19th_is_no_bet(self):
        row = slot_atlas.forecast_one(self.hall, self.rules, dt.date(2026, 7, 19), dt.date(2026, 7, 15), self.holidays)
        self.assertEqual(row["rule_id"], "nku_day19_non_anniversary_avoid")
        self.assertAlmostEqual(row["predicted_mean"], 12.0, places=1)
        self.assertAlmostEqual(row["utility_edge"], -18.0, places=1)
        self.assertEqual(row["rank"], "NO BET")

    def test_anniversary_overrides_regular_19th(self):
        row = slot_atlas.forecast_one(self.hall, self.rules, dt.date(2026, 4, 19), dt.date(2026, 4, 19), self.holidays)
        self.assertEqual(row["rule_id"], "nku_anniversary_0419_monitor")
        self.assertAlmostEqual(row["predicted_mean"], 101.8, places=1)
        self.assertAlmostEqual(row["utility_edge"], 71.8, places=1)
        self.assertEqual(row["rank"], "B")

    def test_11th_and_21st_are_no_bet(self):
        for target in (dt.date(2026, 8, 11), dt.date(2026, 8, 21)):
            row = slot_atlas.forecast_one(self.hall, self.rules, target, dt.date(2026, 7, 15), self.holidays)
            self.assertEqual(row["rule_id"], "nku_day11_21_avoid")
            self.assertEqual(row["rank"], "NO BET")

    def test_seed_metrics_and_validation_queue(self):
        with (ROOT / "seed" / "nakayama_uno_hall_days.csv").open(encoding="utf-8-sig", newline="") as fh:
            rows = list(csv.DictReader(fh))
        self.assertEqual(len(rows), 27)
        self.assertEqual(len({r["result_date"] for r in rows}), 27)
        day1 = [r for r in rows if r["result_date"].startswith("2026-") and r["result_date"][8:] == "01"]
        self.assertEqual(len(day1), 7)
        values = [float(r["avg_diff"]) for r in day1]
        self.assertAlmostEqual(sum(values) / len(values), 67.7143, places=3)
        self.assertEqual(sum(v > 0 for v in values), 5)
        anniversary = [r for r in rows if r["result_date"] in {"2025-04-19", "2026-04-19"}]
        self.assertAlmostEqual(sum(float(r["avg_diff"]) for r in anniversary) / 2, 305.5, places=1)
        queue = json.loads((ROOT / "seed" / "validation_queue.json").read_text(encoding="utf-8"))
        self.assertEqual(len([r for r in queue if r["hall_id"] == "yokohama_nakayama_uno"]), 4)


if __name__ == "__main__":
    unittest.main()

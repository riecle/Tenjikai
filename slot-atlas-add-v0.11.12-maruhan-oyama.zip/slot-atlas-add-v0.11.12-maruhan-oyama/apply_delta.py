#!/usr/bin/env python3
from __future__ import annotations
import csv, json, shutil, subprocess, sys
from pathlib import Path

def merge_json(base_path: Path, add_path: Path, key_fields: tuple[str,...]):
    base=json.load(open(base_path,encoding='utf-8')) if base_path.exists() else []
    add=json.load(open(add_path,encoding='utf-8'))
    idx={tuple(x.get(k) for k in key_fields):i for i,x in enumerate(base)}
    for item in add:
        key=tuple(item.get(k) for k in key_fields)
        if key in idx: base[idx[key]]=item
        else: idx[key]=len(base); base.append(item)
    json.dump(base,open(base_path,'w',encoding='utf-8'),ensure_ascii=False,indent=2)

def main():
    if len(sys.argv)!=2:
        raise SystemExit('usage: python apply_delta.py /path/to/slot_atlas_work6')
    target=Path(sys.argv[1]).resolve(); here=Path(__file__).resolve().parent
    if not (target/'seed').is_dir(): raise SystemExit('target/seed not found')
    shutil.copy2(here/'seed/maruhan_oyama_hall_days.csv',target/'seed/maruhan_oyama_hall_days.csv')
    shutil.copy2(here/'seed/maruhan_oyama_machine_scores.csv',target/'seed/maruhan_oyama_machine_scores.csv')
    merge_json(target/'seed/halls.json',here/'delta/halls_add.json',('hall_id',))
    merge_json(target/'seed/rules.json',here/'delta/rules_add.json',('rule_id',))
    merge_json(target/'seed/calendar_flags.json',here/'delta/calendar_flags_add.json',('flag_date','hall_id','flag_type','flag_name'))
    merge_json(target/'seed/validation_queue.json',here/'delta/validation_queue_add.json',('target_date','hall_id','claim'))
    merge_json(target/'seed/source_snapshots.json',here/'delta/source_snapshots_add.json',('hall_id','source_name','source_url'))
    report=target/'MERGE_REPORT_v0.11.12.md'
    shutil.copy2(here/'MERGE_REPORT_v0.11.12.md',report)
    shutil.copy2(here/'reports/maruhan_oyama_analysis_2026-07-15.md',target/'reports/maruhan_oyama_analysis_2026-07-15.md')
    if (target/'tests').is_dir():
        shutil.copy2(here/'tests/test_maruhan_oyama.py',target/'tests/test_maruhan_oyama.py')
        integrity = target/'tests/test_merge_integrity.py'
        if integrity.exists():
            body = integrity.read_text(encoding='utf-8')
            body = body.replace('def test_merged_hall_set_has_43_unique_halls(self):', 'def test_merged_hall_set_has_44_unique_halls(self):')
            body = body.replace('self.assertEqual(len(self.halls), 43)', 'self.assertEqual(len(self.halls), 44)')
            body = body.replace('self.assertEqual(len(self.by_id), 43)', 'self.assertEqual(len(self.by_id), 44)')
            anchor = '        self.assertIn("ueno_espace_shinkan", self.by_id)\n'
            addition = '        self.assertIn("itabashi_maruhan_oyama", self.by_id)\n'
            if addition not in body and anchor in body:
                body = body.replace(anchor, anchor + addition)
            integrity.write_text(body, encoding='utf-8')
    print('Merged additive data for itabashi_maruhan_oyama.')
    print('Rebuild with: python slot_atlas.py init && python slot_atlas.py generate --start 2026-07-15 --days 365 --run-date 2026-07-15 && python build_dashboard.py')
if __name__=='__main__': main()

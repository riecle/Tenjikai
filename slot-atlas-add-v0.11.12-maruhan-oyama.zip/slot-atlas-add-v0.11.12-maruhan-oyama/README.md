# マルハン大山店 追加差分

このZIPは追加データのみです。

```bash
unzip slot-atlas-add-v0.11.12-maruhan-oyama.zip
python slot-atlas-add-v0.11.12-maruhan-oyama/apply_delta.py /path/to/slot_atlas_work6
cd /path/to/slot_atlas_work6
python slot_atlas.py init
python slot_atlas.py generate --start 2026-07-15 --days 365 --run-date 2026-07-15
python build_dashboard.py
```

`apply_delta.py` は同じIDのレコードを置換し、未登録なら追加します。

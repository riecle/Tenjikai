import csv
import datetime as dt
import json
import pathlib
import sys
import unittest

ROOT = pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
import slot_atlas


class MaruhanOyamaDeltaTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.halls = json.loads((ROOT / "seed" / "halls.json").read_text(encoding="utf-8"))
        cls.rules = json.loads((ROOT / "seed" / "rules.json").read_text(encoding="utf-8"))
        cls.holidays = json.loads((ROOT / "seed" / "holidays.json").read_text(encoding="utf-8"))
        cls.hall = next(h for h in cls.halls if h["hall_id"] == "itabashi_maruhan_oyama")

    def test_seed_has_195_days(self):
        with (ROOT / "seed" / "maruhan_oyama_hall_days.csv").open(encoding="utf-8-sig", newline="") as fh:
            rows = list(csv.DictReader(fh))
        self.assertEqual(len(rows), 195)
        self.assertEqual(rows[0]["result_date"], "2026-01-01")
        self.assertEqual(rows[-1]["result_date"], "2026-07-14")

    def test_exact_7th_is_a(self):
        row = slot_atlas.forecast_one(self.hall, self.rules, dt.date(2026, 8, 7), dt.date(2026, 7, 15), self.holidays)
        self.assertEqual(row["rule_id"], "moy_exact7_full_hall")
        self.assertAlmostEqual(row["predicted_mean"], 173.8, places=1)
        self.assertAlmostEqual(row["utility_edge"], 82.8, places=1)
        self.assertEqual(row["rank"], "A")

    def test_17th_27th_and_1st_are_not_remote_bets(self):
        cases = [
            (dt.date(2026, 7, 17), "moy_day17_monitor"),
            (dt.date(2026, 7, 27), "moy_day27_kill"),
            (dt.date(2026, 8, 1), "moy_day1_monitor"),
        ]
        for target, rule_id in cases:
            with self.subTest(target=target):
                row = slot_atlas.forecast_one(self.hall, self.rules, target, dt.date(2026, 7, 15), self.holidays)
                self.assertEqual(row["rule_id"], rule_id)
                self.assertEqual(row["rank"], "NO BET")


if __name__ == "__main__":
    unittest.main()

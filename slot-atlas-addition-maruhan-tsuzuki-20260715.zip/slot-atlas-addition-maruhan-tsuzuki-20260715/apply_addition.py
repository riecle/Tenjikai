#!/usr/bin/env python3
"""Apply the Maruhan Tsuzuki data-only addition to Slot Atlas 0.11.12."""
from __future__ import annotations

import argparse
import hashlib
import json
import shutil
import sys
import tempfile
from pathlib import Path

BASE_MODEL = "slot-atlas-0.11.12"
ADD_DIR = Path(__file__).resolve().parent


def load_json(path: Path):
    with path.open(encoding="utf-8") as fh:
        return json.load(fh)


def atomic_json(path: Path, data) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.NamedTemporaryFile("w", encoding="utf-8", dir=path.parent, delete=False) as fh:
        json.dump(data, fh, ensure_ascii=False, indent=2)
        fh.write("\n")
        tmp = Path(fh.name)
    tmp.replace(path)


def merge_unique(target: Path, additions: Path, key_fn) -> tuple[int, int]:
    current = load_json(target)
    extra = load_json(additions)
    if not isinstance(current, list) or not isinstance(extra, list):
        raise ValueError(f"list expected: {target} / {additions}")
    by_key = {key_fn(item): item for item in current}
    added = 0
    identical = 0
    for item in extra:
        key = key_fn(item)
        if key in by_key:
            if by_key[key] != item:
                raise ValueError(f"conflicting existing record in {target.name}: {key}")
            identical += 1
            continue
        current.append(item)
        by_key[key] = item
        added += 1
    atomic_json(target, current)
    return added, identical


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as fh:
        for chunk in iter(lambda: fh.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("target", type=Path, help="unpacked Slot Atlas root")
    parser.add_argument("--force-version", action="store_true")
    args = parser.parse_args()
    root = args.target.resolve()
    seed = root / "seed"
    required = [root / "slot_atlas.py", seed / "halls.json", seed / "rules.json", seed / "validation_queue.json", seed / "source_snapshots.json"]
    missing = [str(p) for p in required if not p.exists()]
    if missing:
        print("missing target files:\n- " + "\n- ".join(missing), file=sys.stderr)
        return 2
    model_text = (root / "slot_atlas.py").read_text(encoding="utf-8")
    if BASE_MODEL not in model_text and not args.force_version:
        print(f"target is not {BASE_MODEL}; use --force-version only after reviewing schema compatibility", file=sys.stderr)
        return 3

    backup = seed / "_addition_backups" / "20260715_maruhan_tsuzuki"
    backup.mkdir(parents=True, exist_ok=True)
    for name in ["halls.json", "rules.json", "validation_queue.json", "source_snapshots.json"]:
        dst = backup / name
        if not dst.exists():
            shutil.copy2(seed / name, dst)
    test_path = root / "tests" / "test_merge_integrity.py"
    if test_path.exists() and not (backup / "test_merge_integrity.py.bak").exists():
        shutil.copy2(test_path, backup / "test_merge_integrity.py.bak")

    results = {}
    results["halls"] = merge_unique(seed / "halls.json", ADD_DIR / "seed" / "halls_additions.json", lambda x: x["hall_id"])
    results["rules"] = merge_unique(seed / "rules.json", ADD_DIR / "seed" / "rules_additions.json", lambda x: x["rule_id"])
    results["validations"] = merge_unique(
        seed / "validation_queue.json",
        ADD_DIR / "seed" / "validation_queue_additions.json",
        lambda x: (x["target_date"], x["hall_id"], x["claim"]),
    )
    results["snapshots"] = merge_unique(
        seed / "source_snapshots.json",
        ADD_DIR / "seed" / "source_snapshots_additions.json",
        lambda x: (x["hall_id"], x["source_name"], x["fetched_at"]),
    )

    test_status = "not_present"
    if test_path.exists():
        text = test_path.read_text(encoding="utf-8")
        old = """    def test_merged_hall_set_has_43_unique_halls(self):
        self.assertEqual(len(self.halls), 43)
        self.assertEqual(len(self.by_id), 43)"""
        new = """    def test_merged_hall_set_has_44_unique_halls(self):
        self.assertEqual(len(self.halls), 44)
        self.assertEqual(len(self.by_id), 44)"""
        if old in text:
            text = text.replace(old, new, 1)
            anchor = '        self.assertIn("ueno_espace_shinkan", self.by_id)\n'
            if '        self.assertIn("tsuzuki_maruhan", self.by_id)\n' not in text:
                if anchor not in text:
                    raise ValueError("test patch anchor not found")
                text = text.replace(anchor, anchor + '        self.assertIn("tsuzuki_maruhan", self.by_id)\n', 1)
            test_path.write_text(text, encoding="utf-8")
            test_status = "patched_43_to_44"
        elif new in text and 'self.assertIn("tsuzuki_maruhan", self.by_id)' in text:
            test_status = "already_patched"
        else:
            raise ValueError("unexpected test_merge_integrity.py hall-count block; review patches/test_merge_integrity_43_to_44.diff")

    src_csv = ADD_DIR / "seed" / "maruhan_tsuzuki_hall_days.csv"
    dst_csv = seed / src_csv.name
    if dst_csv.exists():
        if sha256(src_csv) != sha256(dst_csv):
            raise ValueError(f"conflicting CSV already exists: {dst_csv}")
        csv_status = "identical"
    else:
        shutil.copy2(src_csv, dst_csv)
        csv_status = "copied"

    print("Maruhan Tsuzuki addition applied")
    for label, (added, identical) in results.items():
        print(f"- {label}: added={added}, already_identical={identical}")
    print(f"- hall-days CSV: {csv_status}")
    print(f"- compatibility test patch: {test_status}")
    print(f"- backups: {backup}")
    print("Next: python3 slot_atlas.py init && python3 slot_atlas.py generate --start 2026-07-15 --run-date 2026-07-15")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

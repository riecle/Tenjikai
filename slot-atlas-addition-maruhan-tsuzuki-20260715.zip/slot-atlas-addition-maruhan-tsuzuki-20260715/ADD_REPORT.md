# マルハン都筑店 追加レポート

- 追加先想定: Slot Atlas `slot-atlas-0.11.12`
- 追加方式: **追加データのみ**（システム本体・DB・HTMLは同梱しない）
- hall_id: `tsuzuki_maruhan`
- 市場: センター南戦域（鴨居外縁）
- 対象: 46枚貸し411台。低貸14台は別区分
- 尾山台から: 鴨居まで46分 + 徒歩16分 = モデル62分

## 結論

**通常営業はNO BET。周年2月10日だけB監視。**

| 仮説 | 標本 | 平均差枚 | プラス率 | 平均G | 判定 |
|---|---:|---:|---:|---:|---|
| 7のつく日（2026年） | 19 | -237.6枚 | 10.5% | 4936G | NO BET |
| 通常10日（周年除外） | 6 | -153.2枚 | 0.0% | 4491G | NO BET |
| 月日ゾロ目 1/1〜7/7 | 7 | -79.0枚 | 42.9% | 5502G | NO BET |
| 周年2/10（2025・2026） | 2 | +244.0枚 | 100.0% | 6701G | B監視 |

周年実績は2025年 `+203枚 / 6,742G`、2026年 `+285枚 / 6,660G`。強い可能性はあるが、n=2・移動62分のためA以上にはしない。次回2027年2月10日で3年目を検証する。

## 同梱ファイル

- `seed/halls_additions.json`
- `seed/rules_additions.json`
- `seed/validation_queue_additions.json`
- `seed/source_snapshots_additions.json`
- `seed/maruhan_tsuzuki_hall_days.csv`
- `apply_addition.py`
- `addition_manifest.json`
- `patches/test_merge_integrity_43_to_44.diff`（既存の固定件数テストだけ44店へ更新）

## 適用

```bash
python3 apply_addition.py /path/to/slot-atlas-v0_11_12
cd /path/to/slot-atlas-v0_11_12
python3 slot_atlas.py init
python3 slot_atlas.py generate --start 2026-07-15 --run-date 2026-07-15
```

適用スクリプトはJSON正本へ重複なしで追記し、CSVをコピーする。加えて、既存テストの固定店舗数43を44へ更新する最小互換パッチだけを適用する。既存ファイルと内容が衝突した場合は停止する。

## 出典

- スロレポ: https://www.slorepo.com/hole/e3839ee383abe3838fe383b3e983bde7ad91e5ba97code/
- DMMぱちタウン: https://p-town.dmm.com/shops/kanagawa/4613
- P-WORLD: https://www.p-world.co.jp/kanagawa/maruhan-tsuzuki.htm
- Yahoo!乗換案内: https://transit.yahoo.co.jp/search/result/%E5%B0%BE%E5%B1%B1%E5%8F%B0-%E9%B4%A8%E5%B1%85

# アバンザ十条 追加差分 v0.11.14

前段のジュラク王子店差分（v0.11.13）適用後に使用します。

```bash
unzip slot-atlas-add-v0.11.14-avanza-jujo.zip
python slot-atlas-add-v0.11.14-avanza-jujo/apply_delta.py /path/to/slot_atlas_work6
cd /path/to/slot_atlas_work6
python slot_atlas.py init
python slot_atlas.py generate --start 2026-07-15 --days 365 --run-date 2026-07-15
python build_dashboard.py
python -m unittest discover -s tests -v
```

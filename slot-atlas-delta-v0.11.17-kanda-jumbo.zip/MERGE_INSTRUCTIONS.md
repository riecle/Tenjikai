# 差分適用手順 v0.11.17

基準は v0.11.16（コーシン神田店まで統合済み）です。

各 `delta/*.add.json` を対応する `seed/*.json` へ追加してください。同一IDは置換します。validation_queue / source_snapshots は `hall_id=kanda_jumbo` の既存項目を削除後に追加します。

CSVは `delta/kanda_jumbo_condition_summary.csv` を `seed/`、分析レポートは `reports/` へ配置してください。モデル表記を `slot-atlas-0.11.17` に更新し、365日候補を再生成します。検証済み統合後は49店舗・17,885候補です。

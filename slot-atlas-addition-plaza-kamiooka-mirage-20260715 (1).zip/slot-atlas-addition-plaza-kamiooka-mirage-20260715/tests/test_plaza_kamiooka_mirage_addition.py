import csv
import datetime as dt
import json
import pathlib
import sys
import unittest
ROOT=pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
import slot_atlas

class PlazaKamiookaMirageAdditionTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.halls=json.loads((ROOT/'seed'/'halls.json').read_text(encoding='utf-8'))
        cls.rules=json.loads((ROOT/'seed'/'rules.json').read_text(encoding='utf-8'))
        cls.holidays=json.loads((ROOT/'seed'/'holidays.json').read_text(encoding='utf-8'))
        cls.hall=next(h for h in cls.halls if h['hall_id']=='yokohama_plaza_kamiooka_mirage')
    def test_day26_is_a_candidate(self):
        row=slot_atlas.forecast_one(self.hall,self.rules,dt.date(2026,7,26),dt.date(2026,7,15),self.holidays)
        self.assertEqual(row['rule_id'],'pkm_day26_attack')
        self.assertAlmostEqual(row['predicted_mean'],80.2,places=1)
        self.assertAlmostEqual(row['utility_edge'],41.2,places=1)
        self.assertEqual(row['rank'],'A')
    def test_day16_is_no_bet_after_travel(self):
        row=slot_atlas.forecast_one(self.hall,self.rules,dt.date(2026,8,16),dt.date(2026,7,15),self.holidays)
        self.assertEqual(row['rule_id'],'pkm_day16_avoid')
        self.assertAlmostEqual(row['predicted_mean'],32.2,places=1)
        self.assertAlmostEqual(row['utility_edge'],-6.8,places=1)
        self.assertEqual(row['rank'],'NO BET')
    def test_day6_is_no_bet(self):
        row=slot_atlas.forecast_one(self.hall,self.rules,dt.date(2026,8,6),dt.date(2026,7,15),self.holidays)
        self.assertEqual(row['rule_id'],'pkm_day6_avoid')
        self.assertEqual(row['rank'],'NO BET')
    def test_anniversary_is_not_overclaimed(self):
        row=slot_atlas.forecast_one(self.hall,self.rules,dt.date(2026,8,5),dt.date(2026,7,15),self.holidays)
        self.assertIsNone(row['rule_id'])
        self.assertEqual(row['rank'],'NO BET')
    def test_seed_metrics_and_validation_queue(self):
        with (ROOT/'seed'/'plaza_kamiooka_mirage_hall_days.csv').open(encoding='utf-8-sig',newline='') as fh: rows=list(csv.DictReader(fh))
        self.assertEqual(len(rows),22); self.assertEqual(len({r['result_date'] for r in rows}),22)
        d26=[float(r['avg_diff']) for r in rows if r['result_date'].endswith('-26')]
        self.assertEqual(len(d26),7); self.assertAlmostEqual(sum(d26)/len(d26),126.0,places=1); self.assertEqual(sum(v>0 for v in d26),5)
        queue=json.loads((ROOT/'seed'/'validation_queue.json').read_text(encoding='utf-8'))
        self.assertEqual(len([r for r in queue if r['hall_id']=='yokohama_plaza_kamiooka_mirage']),4)
if __name__=='__main__': unittest.main()

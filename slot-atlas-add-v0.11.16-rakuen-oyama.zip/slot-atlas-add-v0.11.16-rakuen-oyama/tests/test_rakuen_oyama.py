import csv
import datetime as dt
import json
import pathlib
import sys
import unittest

ROOT=pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
import slot_atlas

class RakuenOyamaDeltaTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.halls=json.loads((ROOT/'seed/halls.json').read_text(encoding='utf-8'))
        cls.rules=json.loads((ROOT/'seed/rules.json').read_text(encoding='utf-8'))
        cls.holidays=json.loads((ROOT/'seed/holidays.json').read_text(encoding='utf-8'))
        cls.hall=next(h for h in cls.halls if h['hall_id']=='itabashi_rakuen_oyama')

    def test_seed_has_59_unique_special_days(self):
        with (ROOT/'seed/rakuen_oyama_hall_days.csv').open(encoding='utf-8-sig',newline='') as fh: rows=list(csv.DictReader(fh))
        self.assertEqual(len(rows),59)
        self.assertEqual(len({r['result_date'] for r in rows}),59)
        self.assertEqual(rows[0]['result_date'],'2024-06-22')
        self.assertEqual(rows[-1]['result_date'],'2026-07-11')

    def test_day22_is_b(self):
        row=slot_atlas.forecast_one(self.hall,self.rules,dt.date(2026,7,22),dt.date(2026,7,15),self.holidays)
        self.assertEqual(row['rule_id'],'ro_day22_b')
        self.assertAlmostEqual(row['predicted_mean'],117.2,places=1)
        self.assertAlmostEqual(row['utility_edge'],26.2,places=1)
        self.assertEqual(row['rank'],'B')

    def test_0808_uses_zoro_not_8family(self):
        row=slot_atlas.forecast_one(self.hall,self.rules,dt.date(2026,8,8),dt.date(2026,7,15),self.holidays)
        self.assertEqual(row['rule_id'],'ro_month_equals_day_b')
        self.assertAlmostEqual(row['predicted_mean'],113.9,places=1)
        self.assertAlmostEqual(row['utility_edge'],22.9,places=1)
        self.assertEqual(row['rank'],'B')

    def test_11_is_c_and_7_8_families_no_bet(self):
        cases=[(dt.date(2026,8,11),'ro_day11_nearby_c','C'),(dt.date(2026,7,17),'ro_7family_no_bet','NO BET'),(dt.date(2026,7,18),'ro_8family_no_bet','NO BET')]
        for target,rule_id,rank in cases:
            with self.subTest(target=target):
                row=slot_atlas.forecast_one(self.hall,self.rules,target,dt.date(2026,7,15),self.holidays)
                self.assertEqual(row['rule_id'],rule_id)
                self.assertEqual(row['rank'],rank)

    def test_anniversary_and_machine_monitor(self):
        row=slot_atlas.forecast_one(self.hall,self.rules,dt.date(2026,6,22),dt.date(2026,7,15),self.holidays)
        self.assertEqual(row['rule_id'],'ro_anniversary_0622_b')
        self.assertAlmostEqual(row['predicted_mean'],142.0,places=1)
        self.assertAlmostEqual(row['utility_edge'],51.0,places=1)
        self.assertEqual(row['rank'],'B')
        with (ROOT/'seed/rakuen_oyama_machine_scores.csv').open(encoding='utf-8-sig',newline='') as fh: machines=list(csv.DictReader(fh))
        self.assertEqual(len(machines),10)
        self.assertTrue(all(float(r['composite_score'])==0 for r in machines))

if __name__=='__main__': unittest.main()

import csv
import datetime as dt
import json
import pathlib
import sys
import unittest

ROOT = pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
import slot_atlas

class Juraku2OjiDeltaTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.halls=json.loads((ROOT/'seed/halls.json').read_text(encoding='utf-8'))
        cls.rules=json.loads((ROOT/'seed/rules.json').read_text(encoding='utf-8'))
        cls.holidays=json.loads((ROOT/'seed/holidays.json').read_text(encoding='utf-8'))
        cls.hall=next(h for h in cls.halls if h['hall_id']=='kita_juraku2_oji')

    def test_seed_has_25_special_days(self):
        with (ROOT/'seed/juraku2_oji_hall_days.csv').open(encoding='utf-8-sig',newline='') as fh:
            rows=list(csv.DictReader(fh))
        self.assertEqual(len(rows),25)
        self.assertEqual(rows[0]['result_date'],'2026-01-08')
        self.assertEqual(rows[-1]['result_date'],'2026-07-08')

    def test_day18_is_best_but_no_bet(self):
        row=slot_atlas.forecast_one(self.hall,self.rules,dt.date(2026,7,18),dt.date(2026,7,15),self.holidays)
        self.assertEqual(row['rule_id'],'j2_day18_monitor')
        self.assertAlmostEqual(row['predicted_mean'],60.4,places=1)
        self.assertAlmostEqual(row['utility_edge'],-34.6,places=1)
        self.assertEqual(row['rank'],'NO BET')

    def test_day8_28_17_are_no_bet(self):
        cases=[(dt.date(2026,8,8),'j2_day8_no_bet'),(dt.date(2026,7,28),'j2_day28_avoid'),(dt.date(2026,7,17),'j2_day17_avoid')]
        for target,rule_id in cases:
            with self.subTest(target=target):
                row=slot_atlas.forecast_one(self.hall,self.rules,target,dt.date(2026,7,15),self.holidays)
                self.assertEqual(row['rule_id'],rule_id)
                self.assertEqual(row['rank'],'NO BET')

    def test_anniversary_pending_does_not_fire(self):
        row=slot_atlas.forecast_one(self.hall,self.rules,dt.date(2026,8,10),dt.date(2026,7,15),self.holidays)
        self.assertIsNone(row['rule_id'])
        self.assertEqual(row['rank'],'NO BET')

    def test_machine_monitor_has_10_rows(self):
        with (ROOT/'seed/juraku2_oji_machine_scores.csv').open(encoding='utf-8-sig',newline='') as fh:
            rows=list(csv.DictReader(fh))
        self.assertEqual(len(rows),10)
        self.assertTrue(all(float(r['composite_score'])==0 for r in rows))

if __name__=='__main__': unittest.main()

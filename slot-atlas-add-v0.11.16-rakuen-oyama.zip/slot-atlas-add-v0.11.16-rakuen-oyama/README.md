# Slot Atlas 追加差分 v0.11.16 — ジュラク2修正版 + 楽園ハッピーロード大山

## 適用順

1. ベース `slot-atlas-v0_11_12.zip`
2. v0.11.12 マルハン大山
3. v0.11.13 ジュラク王子
4. v0.11.14 アバンザ十条
5. **本 v0.11.16**

> v0.11.15 は適用しないでください。前回ZIPの `apply_delta.py` に構文不備がありました。本ZIPはジュラク2の全データを修正版として再同梱し、さらに楽園ハッピーロード大山を追加する累積差分です。v0.11.15を手作業で適用済みでも、IDマージのため本差分は冪等に適用できます。

## 実行

```bash
python apply_delta.py /path/to/slot_atlas_work6
cd /path/to/slot_atlas_work6
python slot_atlas.py init
python slot_atlas.py generate --start 2026-07-15 --days 365 --run-date 2026-07-15
python build_dashboard.py
python -m unittest discover -s tests -v
```

追加後は48店舗。ジュラク2の修正版5テストと楽園大山5テストを含め、合計155テストを想定しています。

#!/usr/bin/env python3
from __future__ import annotations
import json, re, shutil, sys
from pathlib import Path

def merge_json(base_path:Path,add_path:Path,key_fields:tuple[str,...]):
    base=json.loads(base_path.read_text(encoding='utf-8')) if base_path.exists() else []
    add=json.loads(add_path.read_text(encoding='utf-8'))
    idx={tuple(x.get(k) for k in key_fields):i for i,x in enumerate(base)}
    for item in add:
        key=tuple(item.get(k) for k in key_fields)
        if key in idx: base[idx[key]]=item
        else: idx[key]=len(base);base.append(item)
    base_path.write_text(json.dumps(base,ensure_ascii=False,indent=2),encoding='utf-8')

def main():
    if len(sys.argv)!=2: raise SystemExit('usage: python apply_delta.py /path/to/slot_atlas_work6')
    target=Path(sys.argv[1]).resolve();here=Path(__file__).resolve().parent
    if not (target/'seed').is_dir(): raise SystemExit('target/seed not found')
    halls=json.loads((target/'seed/halls.json').read_text(encoding='utf-8'))
    if not any(h.get('hall_id')=='kita_avanza_jujo' for h in halls):
        raise SystemExit('v0.11.14 アバンザ十条差分を先に適用してください。')
    for name in ['juraku2_oji_hall_days.csv','juraku2_oji_machine_scores.csv','rakuen_oyama_hall_days.csv','rakuen_oyama_machine_scores.csv']:
        shutil.copy2(here/'seed'/name,target/'seed'/name)
    merge_json(target/'seed/halls.json',here/'delta/halls_add.json',('hall_id',))
    merge_json(target/'seed/rules.json',here/'delta/rules_add.json',('rule_id',))
    merge_json(target/'seed/calendar_flags.json',here/'delta/calendar_flags_add.json',('flag_date','hall_id','flag_type','flag_name'))
    merge_json(target/'seed/validation_queue.json',here/'delta/validation_queue_add.json',('target_date','hall_id','claim'))
    merge_json(target/'seed/source_snapshots.json',here/'delta/source_snapshots_add.json',('hall_id','source_name','source_url'))
    shutil.copy2(here/'MERGE_REPORT_v0.11.16.md',target/'MERGE_REPORT_v0.11.16.md')
    for name in ['juraku2_oji_analysis_2026-07-15.md','juraku2_oji_stats_2026-07-15.json','rakuen_oyama_analysis_2026-07-15.md','rakuen_oyama_stats_2026-07-15.json']:
        shutil.copy2(here/'reports'/name,target/'reports'/name)
    if (target/'tests').is_dir():
        for name in ['test_juraku2_oji.py','test_rakuen_oyama.py']:
            shutil.copy2(here/'tests'/name,target/'tests'/name)
        integrity=target/'tests/test_merge_integrity.py'
        if integrity.exists():
            body=integrity.read_text(encoding='utf-8')
            body=re.sub(r'def test_merged_hall_set_has_\d+_unique_halls\(self\):','def test_merged_hall_set_has_48_unique_halls(self):',body)
            body=re.sub(r'self\.assertEqual\(len\(self\.halls\), \d+\)','self.assertEqual(len(self.halls), 48)',body,count=1)
            body=re.sub(r'self\.assertEqual\(len\(self\.by_id\), \d+\)','self.assertEqual(len(self.by_id), 48)',body,count=1)
            insert=[]
            if 'self.assertIn("kita_juraku2_oji", self.by_id)' not in body: insert.append('        self.assertIn("kita_juraku2_oji", self.by_id)')
            if 'self.assertIn("itabashi_rakuen_oyama", self.by_id)' not in body: insert.append('        self.assertIn("itabashi_rakuen_oyama", self.by_id)')
            if insert:
                anchor='        self.assertIn("kita_avanza_jujo", self.by_id)'
                if anchor in body: body=body.replace(anchor,anchor+'\n'+'\n'.join(insert),1)
                else: raise SystemExit('integrity test anchor not found')
            integrity.write_text(body,encoding='utf-8')
    print('Merged corrected Juraku2 Oji plus Rakuen Oyama additive data (48 halls).')
    print('Rebuild with: python slot_atlas.py init && python slot_atlas.py generate --start 2026-07-15 --days 365 --run-date 2026-07-15 && python build_dashboard.py')
if __name__=='__main__': main()

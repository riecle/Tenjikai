# VALIDATION RESULT

- JSON parse: PASS (5 files)
- Required hall_id consistency: PASS
- Unique rule_id: PASS (7/7)
- Unique route_id: PASS (1/1)
- Manifest operation sources exist: PASS
- CSV parse: PASS
- Full-system integration: NOT RUN（差分ZIPのみのため）
- Expected after merge: 50 halls / 18,250 candidate rows

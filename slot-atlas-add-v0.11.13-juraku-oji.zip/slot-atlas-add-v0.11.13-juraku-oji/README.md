# ジュラク王子店 追加差分 v0.11.13

前段のマルハン大山差分（v0.11.12）適用後に使用します。

```bash
unzip slot-atlas-add-v0.11.13-juraku-oji.zip
python slot-atlas-add-v0.11.13-juraku-oji/apply_delta.py /path/to/slot_atlas_work6
cd /path/to/slot_atlas_work6
python slot_atlas.py init
python slot_atlas.py generate --start 2026-07-15 --days 365 --run-date 2026-07-15
python build_dashboard.py
python -m unittest discover -s tests -v
```

import csv
import datetime as dt
import json
import pathlib
import sys
import unittest

ROOT = pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
import slot_atlas

class JurakuOjiDeltaTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.halls=json.loads((ROOT/'seed/halls.json').read_text(encoding='utf-8'))
        cls.rules=json.loads((ROOT/'seed/rules.json').read_text(encoding='utf-8'))
        cls.holidays=json.loads((ROOT/'seed/holidays.json').read_text(encoding='utf-8'))
        cls.hall=next(h for h in cls.halls if h['hall_id']=='kita_juraku_oji')

    def test_seed_has_195_days(self):
        with (ROOT/'seed/juraku_oji_hall_days.csv').open(encoding='utf-8-sig',newline='') as fh:
            rows=list(csv.DictReader(fh))
        self.assertEqual(len(rows),195)
        self.assertEqual(rows[0]['result_date'],'2026-01-01')
        self.assertEqual(rows[-1]['result_date'],'2026-07-14')

    def test_8family_is_positive_but_remote_no_bet(self):
        row=slot_atlas.forecast_one(self.hall,self.rules,dt.date(2026,7,18),dt.date(2026,7,15),self.holidays)
        self.assertEqual(row['rule_id'],'joji_day8family_monitor')
        self.assertAlmostEqual(row['predicted_mean'],60.4,places=1)
        self.assertAlmostEqual(row['utility_edge'],-34.6,places=1)
        self.assertEqual(row['rank'],'NO BET')

    def test_11_and_22_are_explicit_avoid(self):
        for target,rule_id in [(dt.date(2026,8,11),'joji_day11_avoid'),(dt.date(2026,7,22),'joji_day22_avoid')]:
            with self.subTest(target=target):
                row=slot_atlas.forecast_one(self.hall,self.rules,target,dt.date(2026,7,15),self.holidays)
                self.assertEqual(row['rule_id'],rule_id)
                self.assertEqual(row['rank'],'NO BET')

    def test_anniversary_pending_does_not_override_8family(self):
        row=slot_atlas.forecast_one(self.hall,self.rules,dt.date(2026,8,8),dt.date(2026,7,15),self.holidays)
        self.assertEqual(row['rule_id'],'joji_day8family_monitor')
        self.assertEqual(row['rank'],'NO BET')

    def test_machine_monitor_has_10_rows(self):
        with (ROOT/'seed/juraku_oji_machine_scores.csv').open(encoding='utf-8-sig',newline='') as fh:
            rows=list(csv.DictReader(fh))
        self.assertEqual(len(rows),10)

if __name__=='__main__': unittest.main()

#!/usr/bin/env python3
from __future__ import annotations
import json, shutil, sys
from pathlib import Path

def merge_json(base_path:Path,add_path:Path,key_fields:tuple[str,...]):
    base=json.loads(base_path.read_text(encoding='utf-8')) if base_path.exists() else []
    add=json.loads(add_path.read_text(encoding='utf-8'))
    idx={tuple(x.get(k) for k in key_fields):i for i,x in enumerate(base)}
    for item in add:
        key=tuple(item.get(k) for k in key_fields)
        if key in idx: base[idx[key]]=item
        else: idx[key]=len(base);base.append(item)
    base_path.write_text(json.dumps(base,ensure_ascii=False,indent=2),encoding='utf-8')

def main():
    if len(sys.argv)!=2: raise SystemExit('usage: python apply_delta.py /path/to/slot_atlas_work6')
    target=Path(sys.argv[1]).resolve();here=Path(__file__).resolve().parent
    if not (target/'seed').is_dir(): raise SystemExit('target/seed not found')
    halls=json.loads((target/'seed/halls.json').read_text(encoding='utf-8'))
    if not any(h.get('hall_id')=='itabashi_maruhan_oyama' for h in halls):
        raise SystemExit('v0.11.12 マルハン大山差分を先に適用してください。')
    shutil.copy2(here/'seed/juraku_oji_hall_days.csv',target/'seed/juraku_oji_hall_days.csv')
    shutil.copy2(here/'seed/juraku_oji_machine_scores.csv',target/'seed/juraku_oji_machine_scores.csv')
    merge_json(target/'seed/halls.json',here/'delta/halls_add.json',('hall_id',))
    merge_json(target/'seed/rules.json',here/'delta/rules_add.json',('rule_id',))
    merge_json(target/'seed/calendar_flags.json',here/'delta/calendar_flags_add.json',('flag_date','hall_id','flag_type','flag_name'))
    merge_json(target/'seed/validation_queue.json',here/'delta/validation_queue_add.json',('target_date','hall_id','claim'))
    merge_json(target/'seed/source_snapshots.json',here/'delta/source_snapshots_add.json',('hall_id','source_name','source_url'))
    shutil.copy2(here/'MERGE_REPORT_v0.11.13.md',target/'MERGE_REPORT_v0.11.13.md')
    shutil.copy2(here/'reports/juraku_oji_analysis_2026-07-15.md',target/'reports/juraku_oji_analysis_2026-07-15.md')
    shutil.copy2(here/'reports/juraku_oji_stats_2026-07-15.json',target/'reports/juraku_oji_stats_2026-07-15.json')
    if (target/'tests').is_dir():
        shutil.copy2(here/'tests/test_juraku_oji.py',target/'tests/test_juraku_oji.py')
        integrity=target/'tests/test_merge_integrity.py'
        if integrity.exists():
            body=integrity.read_text(encoding='utf-8')
            body=body.replace('def test_merged_hall_set_has_44_unique_halls(self):','def test_merged_hall_set_has_45_unique_halls(self):')
            body=body.replace('self.assertEqual(len(self.halls), 44)','self.assertEqual(len(self.halls), 45)')
            body=body.replace('self.assertEqual(len(self.by_id), 44)','self.assertEqual(len(self.by_id), 45)')
            anchor='        self.assertIn("itabashi_maruhan_oyama", self.by_id)\n'
            addition='        self.assertIn("kita_juraku_oji", self.by_id)\n'
            if addition not in body and anchor in body: body=body.replace(anchor,anchor+addition)
            integrity.write_text(body,encoding='utf-8')
    print('Merged additive data for kita_juraku_oji.')
    print('Rebuild with: python slot_atlas.py init && python slot_atlas.py generate --start 2026-07-15 --days 365 --run-date 2026-07-15 && python build_dashboard.py')
if __name__=='__main__': main()

# 適用手順

manifest.json の operations 順に append/add_file を実行してください。既存キーとの重複時は停止してください。

# 検証結果

- JSON parse: PASS
- unique hall_id/rule_id/route_id: PASS
- CSV columns: PASS
- manifest references: PASS
- contains full system: false
- full-tree integration: NOT RUN
